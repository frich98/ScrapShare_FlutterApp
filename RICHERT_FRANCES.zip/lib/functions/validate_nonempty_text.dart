  String validateText(String inputText) {
    if (inputText == '') {
      return 'This field cannot be left blank.';
    } else {
      return null;
    } 
  }